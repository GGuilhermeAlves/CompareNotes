import { NextResponse } from "next/server"
import pool from "@/lib/db"

export async function GET(request: Request, { params }: { params: Promise<{ id: string }> }) {
  const { id } = await params

  try {
    const result = await pool.query("SELECT * FROM notebooks WHERE id = $1", [id])

    if (result.rows.length === 0) {
      return NextResponse.json({ error: "Notebook não encontrado" }, { status: 404 })
    }

    return NextResponse.json(result.rows[0])
  } catch (error) {
    console.error(error)

    return NextResponse.json({ error: "Erro ao buscar notebook" }, { status: 500 })
  }
}
