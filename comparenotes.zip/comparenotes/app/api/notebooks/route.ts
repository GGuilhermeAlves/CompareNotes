import { NextResponse } from "next/server";
import pool from "@/lib/db";

export async function GET() {
  try {
    const result = await pool.query(
      "SELECT * FROM notebooks ORDER BY nome"
    );

    return NextResponse.json(result.rows);
  } catch (error) {
    console.error(error);

    return NextResponse.json(
      { error: "Erro ao buscar notebooks" },
      { status: 500 }
    );
  }
}

export async function POST(request: Request) {
  try {
    const body = await request.json();

    const result = await pool.query(
      `
      INSERT INTO notebooks (
        nome,
        marca,
        imagem,
        specs,
        dimensoes
      )
      VALUES ($1,$2,$3,$4,$5)
      RETURNING *
      `,
      [
        body.nome,
        body.marca,
        body.imagem,
        JSON.stringify(body.specs),
        JSON.stringify(body.dimensoes),
      ]
    );

    return NextResponse.json(result.rows[0]);
  } catch (error) {
    console.error(error);

    return NextResponse.json(
      { error: "Erro ao cadastrar notebook" },
      { status: 500 }
    );
  }
}